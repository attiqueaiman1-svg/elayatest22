import type { Metadata } from "next";
import { Playfair_Display, Jost } from "next/font/google";
import "./globals.css";

const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  style: ["normal", "italic"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const jost = Jost({
  variable: "--font-jost",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "ELAYA — Carry Your Style, Express Yourself",
  description:
    "Discover beautiful hand-carry bags designed for every moment. ELAYA brings elegance, confidence, and style to everyday life.",
  keywords: [
    "ELAYA",
    "handbags",
    "women bags",
    "hand-carry bags",
    "fashion",
    "minimal",
    "elegant bags",
  ],
  icons: {
    icon: "/favicon.svg",
  },
  openGraph: {
    title: "ELAYA — Carry Your Style, Express Yourself",
    description:
      "Discover beautiful hand-carry bags designed for every moment.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${playfair.variable} ${jost.variable} antialiased bg-cream text-espresso`}
      >
        {children}
      </body>
    </html>
  );
}
