"use client";

import { useState } from "react";
import Image from "next/image";
import {
  ArrowRight,
  Gem,
  Heart,
  Instagram,
  Mail,
  Menu,
  MessageCircle,
  RefreshCcw,
  ShoppingBag,
  Sparkles,
  Truck,
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Reveal } from "@/components/reveal";

/* ---------------------------------- Data ---------------------------------- */

const WHATSAPP_NUMBER = "15550102030";
const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
  "Hello ELAYA! I'd love to know more about your bags."
)}`;
const INSTAGRAM_URL = "https://instagram.com/elaya.atelier";
const INSTAGRAM_HANDLE = "@elaya.atelier";
const EMAIL = "hello@elaya.com";

const NAV_LINKS = [
  { label: "Home", href: "#home" },
  { label: "Products", href: "#collection" },
  { label: "About Us", href: "#about" },
  { label: "Contact", href: "#contact" },
];

type Product = {
  name: string;
  category: string;
  price: string;
  image: string;
  tag?: string;
};

const PRODUCTS: Product[] = [
  {
    name: "Aurelia Tote",
    category: "Pebbled leather tote",
    price: "$129",
    image: "/images/product-tote.png",
    tag: "Bestseller",
  },
  {
    name: "Blossom Chain Bag",
    category: "Quilted shoulder bag",
    price: "$89",
    image: "/images/product-shoulder.png",
    tag: "New",
  },
  {
    name: "Sofia Top-Handle",
    category: "Structured mini bag",
    price: "$99",
    image: "/images/product-tophandle.png",
  },
  {
    name: "Luna Evening Clutch",
    category: "Satin evening clutch",
    price: "$69",
    image: "/images/product-clutch.png",
    tag: "Limited",
  },
];

function shopUrl(product: Product) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    `Hello ELAYA! I'd love to order the ${product.name} (${product.price}).`
  )}`;
}

/* --------------------------------- Navbar --------------------------------- */

function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-espresso/5 bg-cream/80 backdrop-blur-md">
      <nav
        aria-label="Main navigation"
        className="mx-auto flex h-20 max-w-6xl items-center justify-between px-5 sm:px-8"
      >
        {/* Logo */}
        <a
          href="#home"
          className="font-serif text-2xl font-semibold tracking-[0.35em] text-espresso"
          aria-label="ELAYA home"
        >
          ELAYA<span className="text-blush">.</span>
        </a>

        {/* Desktop links */}
        <ul className="hidden items-center gap-9 md:flex">
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="text-xs font-medium uppercase tracking-[0.2em] text-espresso/70 transition-colors hover:text-blush"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        {/* Desktop CTA */}
        <a
          href="#collection"
          className="hidden rounded-full bg-espresso px-6 py-2.5 text-xs font-medium uppercase tracking-[0.2em] text-cream transition-colors hover:bg-mocha md:inline-flex"
        >
          Shop Now
        </a>

        {/* Mobile menu */}
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <button
              type="button"
              aria-label="Open menu"
              className="inline-flex h-11 w-11 items-center justify-center rounded-full text-espresso transition-colors hover:bg-sand md:hidden"
            >
              <Menu className="h-6 w-6" />
            </button>
          </SheetTrigger>
          <SheetContent
            side="right"
            className="w-72 border-espresso/10 bg-cream"
          >
            <SheetHeader>
              <SheetTitle className="font-serif text-xl font-semibold tracking-[0.35em] text-espresso">
                ELAYA<span className="text-blush">.</span>
              </SheetTitle>
            </SheetHeader>
            <nav aria-label="Mobile navigation" className="mt-4 px-4">
              <ul className="flex flex-col gap-2">
                {NAV_LINKS.map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      onClick={() => setOpen(false)}
                      className="block rounded-2xl px-4 py-3 font-serif text-lg text-espresso transition-colors hover:bg-sand"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
              <a
                href="#collection"
                onClick={() => setOpen(false)}
                className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-espresso px-6 py-3 text-xs font-medium uppercase tracking-[0.2em] text-cream transition-colors hover:bg-mocha"
              >
                <ShoppingBag className="h-4 w-4" />
                Shop Now
              </a>
            </nav>
          </SheetContent>
        </Sheet>
      </nav>
    </header>
  );
}

/* ---------------------------------- Hero ----------------------------------- */

function Hero() {
  return (
    <section id="home" className="relative overflow-hidden pt-28 lg:pt-32">
      {/* soft background washes */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-24 -left-24 h-96 w-96 rounded-full bg-blush-soft blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-1/3 -right-32 h-[28rem] w-[28rem] rounded-full bg-sand blur-3xl"
      />

      <div className="relative mx-auto grid max-w-6xl items-center gap-14 px-5 pb-20 sm:px-8 lg:grid-cols-2 lg:gap-10 lg:pb-28">
        {/* Copy */}
        <Reveal className="order-2 text-center lg:order-1 lg:text-left">
          <p className="mb-6 inline-flex items-center gap-3 text-[0.7rem] font-medium uppercase tracking-[0.35em] text-mocha">
            <span aria-hidden="true" className="h-px w-8 bg-mocha/50" />
            New Season · 2026 Collection
            <span aria-hidden="true" className="h-px w-8 bg-mocha/50 lg:hidden" />
          </p>

          <h1 className="font-serif text-4xl leading-tight text-espresso sm:text-5xl lg:text-6xl lg:leading-[1.15]">
            Carry Your Style,
            <br />
            <em className="text-blush">Express Yourself.</em>
          </h1>

          <p className="mx-auto mt-6 max-w-md text-base font-light leading-relaxed text-mocha sm:text-lg lg:mx-0">
            Discover beautiful hand-carry bags designed for every moment.
          </p>

          <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center lg:justify-start">
            <a
              href="#collection"
              className="group inline-flex items-center gap-2 rounded-full bg-espresso px-8 py-4 text-xs font-medium uppercase tracking-[0.25em] text-cream shadow-lg shadow-espresso/20 transition-all hover:-translate-y-0.5 hover:bg-mocha"
            >
              Explore Collection
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="#about"
              className="text-xs font-medium uppercase tracking-[0.25em] text-espresso/70 underline-offset-8 transition-colors hover:text-blush hover:underline"
            >
              Our Story
            </a>
          </div>

          {/* trust points */}
          <ul className="mt-12 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-xs text-mocha lg:justify-start">
            <li className="inline-flex items-center gap-2">
              <Truck className="h-4 w-4 text-blush" aria-hidden="true" />
              Free shipping over $75
            </li>
            <li className="inline-flex items-center gap-2">
              <RefreshCcw className="h-4 w-4 text-blush" aria-hidden="true" />
              30-day easy returns
            </li>
            <li className="inline-flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-blush" aria-hidden="true" />
              Handcrafted details
            </li>
          </ul>
        </Reveal>

        {/* Image */}
        <Reveal delay={150} className="order-1 lg:order-2">
          <div className="relative mx-auto w-full max-w-sm lg:max-w-md">
            {/* arch frame decoration */}
            <div
              aria-hidden="true"
              className="absolute -top-4 left-1/2 h-full w-full -translate-x-[42%] rounded-b-[2rem] rounded-t-full border border-blush/40"
            />
            <div className="relative aspect-[3/4] overflow-hidden rounded-b-[2rem] rounded-t-full shadow-2xl shadow-blush/20">
              <Image
                src="/images/hero-bag.png"
                alt="ELAYA signature handbag in soft cream leather with gold hardware"
                fill
                priority
                sizes="(min-width: 1024px) 28rem, (min-width: 640px) 24rem, 90vw"
                className="object-cover"
              />
            </div>

            {/* floating badge */}
            <div className="absolute -bottom-5 left-1/2 flex w-max -translate-x-1/2 items-center gap-3 rounded-2xl border border-espresso/5 bg-white/90 px-5 py-3.5 shadow-xl shadow-espresso/10 backdrop-blur sm:left-auto sm:right-[-1rem] sm:translate-x-0">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-blush-soft">
                <Heart className="h-5 w-5 text-blush" aria-hidden="true" />
              </span>
              <span className="text-left">
                <span className="block text-sm font-medium text-espresso">
                  Loved by 2,000+ women
                </span>
                <span className="block text-xs text-mocha">
                  Elegant · Everyday · Yours
                </span>
              </span>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* -------------------------------- Collection -------------------------------- */

function ProductCard({ product }: { product: Product }) {
  return (
    <article className="group flex flex-col overflow-hidden rounded-3xl border border-espresso/5 bg-white shadow-sm transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl hover:shadow-blush/10">
      <div className="relative aspect-[3/4] overflow-hidden">
        <Image
          src={product.image}
          alt={`${product.name} — ${product.category}`}
          fill
          sizes="(min-width: 1024px) 21rem, (min-width: 640px) 45vw, 92vw"
          className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
        />
        {product.tag ? (
          <span className="absolute top-4 left-4 rounded-full bg-cream/90 px-3.5 py-1.5 text-[0.65rem] font-medium uppercase tracking-[0.2em] text-espresso backdrop-blur">
            {product.tag}
          </span>
        ) : null}
      </div>

      <div className="flex flex-1 flex-col p-5 sm:p-6">
        <p className="text-[0.65rem] font-medium uppercase tracking-[0.25em] text-mocha/70">
          {product.category}
        </p>
        <h3 className="mt-1.5 font-serif text-xl text-espresso">
          {product.name}
        </h3>
        <p className="mt-2 text-lg font-medium text-blush">{product.price}</p>

        <a
          href={shopUrl(product)}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-espresso px-6 py-3 text-xs font-medium uppercase tracking-[0.2em] text-cream transition-colors hover:bg-blush"
          aria-label={`Shop now — order the ${product.name} via WhatsApp`}
        >
          <ShoppingBag className="h-4 w-4" aria-hidden="true" />
          Shop Now
        </a>
      </div>
    </article>
  );
}

function Collection() {
  return (
    <section id="collection" className="bg-sand/60 py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="mb-4 text-[0.7rem] font-medium uppercase tracking-[0.35em] text-blush">
            Our Collection
          </p>
          <h2 className="font-serif text-3xl text-espresso sm:text-4xl lg:text-5xl">
            Signature Pieces
          </h2>
          <p className="mt-4 font-light text-mocha">
            Four silhouettes, thoughtfully crafted to carry your every moment —
            from busy mornings to golden evenings.
          </p>
        </Reveal>

        <div className="mt-14 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 lg:gap-8">
          {PRODUCTS.map((product, i) => (
            <Reveal key={product.name} delay={i * 100}>
              <ProductCard product={product} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------------------------- About ----------------------------------- */

const VALUES = [
  {
    icon: Sparkles,
    title: "Elegance",
    text: "Soft palettes and graceful shapes, designed to complement every outfit.",
  },
  {
    icon: Heart,
    title: "Confidence",
    text: "Pieces that feel as beautiful as they look — from first coffee to last dance.",
  },
  {
    icon: Gem,
    title: "Style",
    text: "Timeless minimalism for work, weekends, and everything in between.",
  },
];

function About() {
  return (
    <section id="about" className="py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2.5rem] bg-sand px-6 py-16 text-center sm:px-12 lg:px-20">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -top-16 -right-16 h-64 w-64 rounded-full bg-blush-soft blur-3xl"
            />
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -bottom-16 -left-16 h-64 w-64 rounded-full bg-beige/70 blur-3xl"
            />

            <p className="relative mb-4 text-[0.7rem] font-medium uppercase tracking-[0.35em] text-blush">
              About ELAYA
            </p>
            <blockquote className="relative mx-auto max-w-3xl font-serif text-2xl leading-relaxed text-espresso sm:text-3xl lg:text-[2.1rem] lg:leading-[1.5]">
              “ELAYA is a creative fashion brand bringing{" "}
              <em className="text-blush">elegance</em>,{" "}
              <em className="text-blush">confidence</em>, and{" "}
              <em className="text-blush">style</em> to everyday life.”
            </blockquote>
            <p className="relative mx-auto mt-6 max-w-xl font-light leading-relaxed text-mocha">
              Every ELAYA bag begins as a sketch inspired by the women around
              us — and ends in your hands as a quiet statement of who you are.
            </p>

            <div className="relative mt-12 grid gap-8 sm:grid-cols-3">
              {VALUES.map((value) => (
                <div
                  key={value.title}
                  className="flex flex-col items-center gap-3"
                >
                  <span className="flex h-12 w-12 items-center justify-center rounded-full bg-white shadow-sm">
                    <value.icon
                      className="h-5 w-5 text-blush"
                      aria-hidden="true"
                    />
                  </span>
                  <h3 className="font-serif text-lg text-espresso">
                    {value.title}
                  </h3>
                  <p className="max-w-[16rem] text-sm font-light leading-relaxed text-mocha">
                    {value.text}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* --------------------------------- Contact ---------------------------------- */

const CONTACT_CARDS = [
  {
    id: "whatsapp",
    title: "WhatsApp",
    text: "Chat with us directly — we usually reply within minutes.",
    action: "Chat on WhatsApp",
    href: WHATSAPP_URL,
    external: true,
    buttonClass: "bg-[#25D366] text-white hover:bg-[#1fb857]",
    icon: MessageCircle,
    iconClass: "bg-[#25D366]/10 text-[#1da851]",
  },
  {
    id: "instagram",
    title: "Instagram",
    text: "Follow for new arrivals, styling ideas and behind-the-scenes.",
    action: `Follow ${INSTAGRAM_HANDLE}`,
    href: INSTAGRAM_URL,
    external: true,
    buttonClass:
      "border border-espresso/20 text-espresso hover:bg-espresso hover:text-cream",
    icon: Instagram,
    iconClass: "bg-blush-soft text-blush",
  },
  {
    id: "email",
    title: "Email",
    text: "For orders, collaborations or questions — write to us anytime.",
    action: EMAIL,
    href: `mailto:${EMAIL}`,
    external: false,
    buttonClass: "bg-espresso text-cream hover:bg-mocha",
    icon: Mail,
    iconClass: "bg-beige/70 text-mocha",
  },
];

function Contact() {
  return (
    <section id="contact" className="bg-sand/60 py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="mb-4 text-[0.7rem] font-medium uppercase tracking-[0.35em] text-blush">
            Contact
          </p>
          <h2 className="font-serif text-3xl text-espresso sm:text-4xl lg:text-5xl">
            Get in Touch
          </h2>
          <p className="mt-4 font-light text-mocha">
            We would love to hear from you — pick your favorite way to say
            hello.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {CONTACT_CARDS.map((card, i) => (
            <Reveal key={card.id} delay={i * 100}>
              <div className="flex h-full flex-col items-center rounded-3xl border border-espresso/5 bg-white p-8 text-center shadow-sm transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl hover:shadow-blush/10">
                <span
                  className={`flex h-14 w-14 items-center justify-center rounded-full ${card.iconClass}`}
                >
                  <card.icon className="h-6 w-6" aria-hidden="true" />
                </span>
                <h3 className="mt-5 font-serif text-xl text-espresso">
                  {card.title}
                </h3>
                <p className="mt-2 flex-1 text-sm font-light leading-relaxed text-mocha">
                  {card.text}
                </p>
                <a
                  href={card.href}
                  {...(card.external
                    ? { target: "_blank", rel: "noopener noreferrer" }
                    : {})}
                  className={`mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full px-6 py-3 text-xs font-medium uppercase tracking-[0.2em] transition-colors ${card.buttonClass}`}
                  aria-label={`${card.action} — ${card.title}`}
                >
                  {card.action}
                </a>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------------------------- Footer ----------------------------------- */

function Footer() {
  return (
    <footer className="mt-auto bg-espresso text-cream">
      <div className="mx-auto max-w-6xl px-5 py-14 sm:px-8">
        <div className="flex flex-col items-center justify-between gap-10 md:flex-row md:items-start">
          {/* brand */}
          <div className="text-center md:text-left">
            <p className="font-serif text-2xl font-semibold tracking-[0.35em]">
              ELAYA<span className="text-blush">.</span>
            </p>
            <p className="mt-3 max-w-xs text-sm font-light leading-relaxed text-cream/60">
              Carry your style, express yourself — elegant bags for every
              moment.
            </p>
          </div>

          {/* quick links */}
          <nav aria-label="Footer navigation">
            <ul className="flex flex-wrap items-center justify-center gap-x-8 gap-y-3">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-xs font-medium uppercase tracking-[0.2em] text-cream/70 transition-colors hover:text-blush"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* socials */}
          <div className="flex items-center gap-3">
            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="ELAYA on Instagram"
              className="flex h-11 w-11 items-center justify-center rounded-full border border-cream/20 text-cream/80 transition-colors hover:border-blush hover:text-blush"
            >
              <Instagram className="h-5 w-5" aria-hidden="true" />
            </a>
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="ELAYA on WhatsApp"
              className="flex h-11 w-11 items-center justify-center rounded-full border border-cream/20 text-cream/80 transition-colors hover:border-blush hover:text-blush"
            >
              <MessageCircle className="h-5 w-5" aria-hidden="true" />
            </a>
            <a
              href={`mailto:${EMAIL}`}
              aria-label="Email ELAYA"
              className="flex h-11 w-11 items-center justify-center rounded-full border border-cream/20 text-cream/80 transition-colors hover:border-blush hover:text-blush"
            >
              <Mail className="h-5 w-5" aria-hidden="true" />
            </a>
          </div>
        </div>

        <div className="mt-12 border-t border-cream/15 pt-6 text-center">
          <p className="text-xs font-light tracking-[0.15em] text-cream/60">
            Copyright © 2026 ELAYA. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}

/* ----------------------------------- Page ------------------------------------ */

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <Collection />
        <About />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
