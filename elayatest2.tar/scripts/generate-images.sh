#!/bin/bash
# Generate ELAYA brand imagery: 1 hero + 4 product shots
set -e
mkdir -p /home/z/my-project/public/images
cd /home/z/my-project/public/images

echo "Generating hero image..."
z-ai image -p "Luxury elegant women's cream beige leather handbag with gold hardware displayed on white pedestal, draped soft silk fabric in background, cream and light blush pink tones, soft diffused studio lighting, high fashion editorial product photography, minimalist feminine aesthetic, warm airy atmosphere, high quality, detailed" -o "./hero-bag.png" -s 864x1152

echo "Generating product 1: Aurelia Tote..."
z-ai image -p "Luxury cream ivory white pebbled leather tote bag for women, structured silhouette with top handles, professional product photography centered on seamless soft beige studio background, soft natural window lighting with gentle shadow, minimalist elegant e-commerce style, high quality, detailed" -o "./product-tote.png" -s 864x1152

echo "Generating product 2: Blossom Shoulder..."
z-ai image -p "Elegant light blush pink quilted leather shoulder bag with thin gold chain strap for women, luxury minimalist design, professional product photography centered on seamless warm cream studio background, soft diffused lighting, feminine e-commerce style, high quality, detailed" -o "./product-shoulder.png" -s 864x1152

echo "Generating product 3: Sofia Top-Handle..."
z-ai image -p "Elegant taupe beige structured top-handle handbag for women with small gold clasp, trapezoid silhouette, luxury minimalist design, professional product photography centered on seamless ivory cream studio background, soft natural lighting with delicate shadow, e-commerce style, high quality, detailed" -o "./product-tophandle.png" -s 864x1152

echo "Generating product 4: Luna Clutch..."
z-ai image -p "Elegant soft blush rose satin evening clutch bag for women with slim gold frame and clasp, luxury minimalist design, professional product photography centered on seamless soft white cream studio background, gentle diffused lighting, feminine e-commerce style, high quality, detailed" -o "./product-clutch.png" -s 864x1152

echo "All images generated."
ls -la /home/z/my-project/public/images/
